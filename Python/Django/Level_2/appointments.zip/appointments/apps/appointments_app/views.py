from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.contrib import messages
from .models import User, Appointment
import datetime

# Create your views here.
def index(request):
	if 'name' in request.session:
		return redirect(reverse('appointments_app:success'))
	else:
		return render(request, 'appointments_app/index.html')

def register(request):
	valid, res = User.objects.validate_and_add(request.POST)
	if valid:
		user = User.objects.get(email=request.POST['email'])
		request.session['name'] = user.name
		request.session['id'] = user.id
		return redirect(reverse('appointments_app:success'))
	else:
		for error in res:
			messages.error(request, error)
		return redirect(reverse('appointments_app:index'))

def login(request):
	valid, res = User.objects.login(request.POST)
	if valid:
		user = User.objects.get(email=request.POST['email'])
		request.session['name'] = user.name
		request.session['id'] = user.id
		return redirect(reverse('appointments_app:success'))
	else:
		for error in res:
			messages.error(request, error)
		return redirect(reverse('appointments_app:index'))

def success(request):
	i = datetime.datetime.now()
	DateTime = ("%s/%s/%s" % (i.month,i.day,i.year))
	today = datetime.datetime.today()
	context = {
		'DateTime': DateTime,
		'todayappointments': Appointment.objects.filter(user=User.objects.get(name=request.session['name']), date=today).order_by('-date'),
		'laterappointments': Appointment.objects.filter(user=User.objects.get(name=request.session['name']), date__gt=today).order_by('-date'),
	}
	return render(request, 'appointments_app/appointments.html', context)

def logout(request):
	request.session.clear()
	return redirect(reverse('appointments_app:index'))

######

def create_appointment(request):
	valid, res = Appointment.objects.validate_and_add(request.POST)
	if valid:
		return redirect(request.META.get('HTTP_REFERER'))
	else:
		for error in res:
			messages.error(request, error)
		return redirect(request.META.get('HTTP_REFERER'))

def delete_appointment(request, id):
	appointment = Appointment.objects.get(id=id)
	appointment.delete()
	return redirect(request.META.get('HTTP_REFERER'))

def edit(request, id):
	context = {
		'appointment': Appointment.objects.get(id=id)
	}
	return render(request, 'appointments_app/update.html', context)

def update_appointment(request, id):
	Appointment.objects.update_appointment(request.POST, id)
	return redirect(reverse('appointments_app:success'))


