from __future__ import unicode_literals

from django.db import models
import bcrypt
import datetime

# Create your models here.
class UserManager(models.Manager):

	def create_user(self, name, email, birth_date, pw_hash):
		user = self.create(name=name, email=email, birth_date=birth_date, password=pw_hash)
		return (True, user)

	def hash_password(self, password):
		password = password.encode()
		hashed_password = bcrypt.hashpw(password, bcrypt.gensalt())
		return hashed_password

	def compare_passwords(self, user, password):
		pw = password.encode()
		hashed_pw = user.password.encode()
		if bcrypt.hashpw(pw, hashed_pw) == hashed_pw:
			return True
		else:
			return False

	def validate_and_add(self, data):
		name = data['name']
		email = data['email']
		password = data['password']
		confirm_password = data['confirm_password']
		birth_date = data['birth_date']
		errors = []
		if len(name)<1:
			errors.append('Name field cannot be left empty.')
		if len(email)<1:
			errors.append('Email field cannot be left empty.')
		if len(password)<8:
			errors.append('Password field must contain at least eight characters.')
		if password != confirm_password:
			errors.append('Please ensure password and password confirmation match.')
		if not birth_date:
			errors.append('Please include a birth date.')
		if errors:
			return (False, errors)
		else:
			try:
				match = self.get(email=email)
				errors.append('Whoops! Email already exists in our database.')
				return (False, errors)
			except:
				pw_hash = self.hash_password(password)
				user = self.create_user(name, email, birth_date, pw_hash)
				return (True, user)

	def login(self, data):
		password = data['password']
		errors = []
		if len(data['email'])<1:
			errors.append('Please do not neglect to fill out your email to log in.')
		if len(password)<1:
			errors.append('Password cannot be left blank.')
		if errors:
			return(False, errors)
		try:
			user = self.get(email=data['email'])
			if self.compare_passwords(user, password):
				return (True, user)
		except:
			errors.append("Whoops! Looks like that email doesn't exist in the database")
			return (False, errors)

class User(models.Model):
	name = models.CharField(max_length=125)
	email = models.CharField(max_length=125)
	password = models.CharField(max_length=255)
	birth_date = models.DateField()
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	objects = UserManager()

##########

class AppointmentManager(models.Manager):
	def create_appointment(self, date, time, notes, user):
		appointment = self.create(date=date, time=time, notes=notes, user=user)
		return (True, appointment)


	def validate_and_add(self, data):
		errors = []
		date = data['date']
		time = data['time']
		notes = data['tasks']
		user_id = data['user_id']
		if not date:
			errors.append('Please include a date.')
		if not time:
			errors.append('Please include a time.')
		if len(notes)<1:
			errors.append('Please include a note for this appointment.')
		if errors:
			return (False, errors)
		else:
			user = User.objects.get(id=int(user_id))
			appointment = self.create_appointment(date, time, notes, user)
			return (True, appointment)

	def update_appointment(self, data, id):
		thing = self.filter(id=id)

		if data['tasks']:
			thing.update(notes=data['tasks'])

		if data['date']:
			thing.update(date=data['date'])

		if data['time']:
			thing.update(time=data['time'])

		if data['status']:
			thing.update(status=data['status'])

		return True

class Appointment(models.Model):
	date = models.DateField()
	time = models.TimeField()
	notes = models.CharField(max_length=255)
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)
	user = models.ForeignKey(User)
	status = models.CharField(max_length=15, default='Pending')

	objects = AppointmentManager()

