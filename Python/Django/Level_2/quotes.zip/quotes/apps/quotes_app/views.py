from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.contrib import messages
from .models import Quote
from ..user_app.models import User

# Create your views here.
def index(request):
	if 'id' not in request.session:
		return redirect(reverse('user_app:index'))
	context = {
		'quotes': Quote.objects.all().order_by('-created_at'),
		'favourites' : Quote.objects.filter(favourited_by=User.objects.get(id=request.session['id'])),
	}
	return render(request, 'quotes_app/index.html', context)

def user(request, id):
	context = {
		'user' : User.objects.get(id=id),
		'quotes' : Quote.objects.filter(user=User.objects.get(id=id)),
	}
	return render(request, 'quotes_app/user.html', context)

def create(request, id):
	valid, res = Quote.objects.validate_and_add(request.POST, id)
	if not valid:
		for error in res:
			messages.error(request, error)
	return redirect(reverse('quotes_app:index'))

def add_to_favourites(request):
	user = User.objects.get(id=request.POST['user_id'])
	quote = Quote.objects.get(id=request.POST['quote_id'])
	quote.favourited_by.add(user)
	print request.POST
	return redirect(reverse('quotes_app:index'))

def remove(request):
	user = User.objects.get(id=request.POST['user_id'])
	quote = Quote.objects.get(id=request.POST['quote_id'])
	quote.favourited_by.remove(user)
	print request.POST
	return redirect(reverse('quotes_app:index'))

