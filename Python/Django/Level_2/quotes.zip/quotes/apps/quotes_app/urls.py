from django.conf.urls import url
from . import views

urlpatterns = [
	url(r'^$', views.index, name='index'),
	url(r'^user(?P<id>\d+)$', views.user, name='user'),
	url(r'^create(?P<id>\d+)$', views.create, name='create'),
	url(r'^add_to_favourites$', views.add_to_favourites, name='add_to_favourites'),
	url(r'^remove$', views.remove, name='remove')
]