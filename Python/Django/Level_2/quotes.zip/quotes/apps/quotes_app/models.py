from __future__ import unicode_literals

from django.db import models
from ..user_app.models import User

# Create your models here.
class QuoteManager(models.Manager):
	def create_quote(self, quote, author, user):
		quote = self.create(quote=quote, author=author, user=user)
		return (True, quote)

	def validate_and_add(self, data, id):
		errors = []
		if len(data['author'])<3:
			errors.append('Author field must contain at least three characters.')
		if len(data['quote'])<10:
			errors.append('Quote field must contain at least 10 characters.')
		if errors:
			return (False, errors)
		else:
			user = User.objects.get(id = id)
			quote = self.create_quote(data['quote'], data['author'], user)
			return (True, quote)


class Quote(models.Model):
	quote = models.CharField(max_length=1000)
	author = models.CharField(max_length=255)
	favourited_by = models.ManyToManyField(User, related_name='favourites')
	user = models.ForeignKey(User, related_name='quotes')
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	objects = QuoteManager()
