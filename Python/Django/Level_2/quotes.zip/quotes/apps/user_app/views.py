from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.contrib import messages
from ..user_app.models import User

# Create your views here.
def index(request):
	if 'id' in request.session:
		return redirect(reverse('quotes_app:index'))
	else:
		return render(request, 'user_app/index.html')

def register(request):
	valid, res = User.objects.validate_and_add(request.POST)
	if valid:
		user = User.objects.get(email=request.POST['email'])
		request.session['alias'] = user.alias
		request.session['id'] = user.id
		return redirect(reverse('quotes_app:index'))
	else:
		for error in res:
			messages.error(request, error)
	return redirect(reverse('user_app:index'))

def login(request):
	valid, res = User.objects.login(request.POST)
	if valid:
		user = User.objects.get(email=request.POST['email'])
		request.session['alias'] = user.alias
		request.session['id'] = user.id
		return redirect(reverse('quotes_app:index'))
	else:
		for error in res:
			messages.error(request, error)
	return redirect(reverse('user_app:index'))

def logout(request):
	request.session.clear()
	return redirect(reverse('user_app:index'))