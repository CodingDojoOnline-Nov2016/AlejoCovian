from __future__ import unicode_literals

from django.apps import AppConfig


class ClientResourcesAppConfig(AppConfig):
    name = 'client_resources_app'
