from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.contrib import messages
from ..poke_app.models import Poke 
from ..user_app.models import User

# Create your views here.
def index(request):
	context = {
		'users' : User.objects.all(),
	}
	return render(request, 'poke_app/index.html', context)

def create_poke(request, id):
	Poke.objects.validate_poke(request.POST, id)
	return redirect(reverse('poke_app:index'))