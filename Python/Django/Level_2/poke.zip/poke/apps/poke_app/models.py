from __future__ import unicode_literals

from django.db import models
from ..user_app.models import User

# Create your models here.
class PokeManager(models.Manager):

	def create_poke(self, to_user, user):
		poke = self.create(to_user=to_user, from_user=user)
		return poke

	def validate_poke(self, data, id):
		to_user = User.objects.get(id=id)
		from_user = int(data['from_user'])
		poke = self.create_poke(to_user, from_user)

class Poke(models.Model):
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)
	objects = PokeManager()
	to_user = models.ForeignKey(User, related_name="pokes")
	from_user = models.SmallIntegerField()