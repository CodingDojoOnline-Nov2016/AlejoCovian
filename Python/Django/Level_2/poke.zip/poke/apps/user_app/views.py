from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.contrib import messages
from ..user_app.models import User

# Create your views here.
def index(request):
	if 'user' not in request.session:
		return render(request, 'user_app/index.html')
	else:
		return redirect(reverse('poke_app:index'))

def register(request):
	valid, res = User.objects.validate_and_add(request.POST)
	if valid:
		user = User.objects.get(email=request.POST['email'])
		request.session['alias'] = user.alias
		request.session['id'] = user.id
		return redirect(reverse('poke_app:index'))
	else:
		for error in res:
			messages.error(request, error)
	return redirect(reverse('user_app:index'))

def login(request):
	valid, res = User.objects.login(request.POST)
	if valid:
		user = User.objects.get(email=request.POST['email'])
		request.session['alias'] = user.alias
		request.session['id'] = user.id
		return redirect(reverse('poke_app:index'))
	else:
		for error in res:
			messages.error(request, error)
	return redirect(reverse('user_app:index'))

def logout(request):
	request.session.clear()
	return redirect(reverse('user_app:index'))