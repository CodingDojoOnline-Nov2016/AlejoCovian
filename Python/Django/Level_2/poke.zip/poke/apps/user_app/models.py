from __future__ import unicode_literals

from django.db import models
import bcrypt

# Create your models here.
class UserManager(models.Manager):

	def create_user(self, name, alias, email, birthday, password):
		user = self.create(name=name, alias=alias, email=email, birthday=birthday, password=password)
		return (True, user)

	def hash_password(self, password):
		password = password.encode()
		hashed_password = bcrypt.hashpw(password, bcrypt.gensalt())
		return hashed_password

	def compare_passwords(self, user, password):
		pw = password.encode()
		hashed_pw = user.password.encode()
		if bcrypt.hashpw(pw, hashed_pw) == hashed_pw:
			return True
		else:
			return False

	def validate_and_add(self, data):
		errors = []
		if len(data['name'])<1:
			errors.append('Name cannot be left blank.')
		if len(data['alias'])<1:
			errors.append('Alias cannot be left blank.')
		if len(data['email'])<1:
			errors.append('Email cannot be left blank.')
		if len(data['password'])<1:
			errors.append('Password cannot be left blank.')
		if data['password'] != data['confirm_password']:
			errors.append('Password and password confirmation must match.')
		if not data['birth_date']:
			errors.append('Please include a birthday.')
		if errors:
			return (False, errors)
		else:
			try:
				match = self.get(email=email)
				errors.append('Whoops! Email already exists in our database.')
				return (False, errors)
			except:
				pw_hash = self.hash_password(data['password'])
				user = self.create_user(data['name'], data['alias'], data['email'], data['birth_date'], pw_hash)
				return (True, user)

	def login(self, data):
		password = data['password']
		errors = []
		if len(data['email'])<1:
			errors.append('Please input an email.')
		if len(password)<1:
			errors.append('Please input a password.')
		if errors:
			return (False, errors)
		try:
			user = self.get(email=data['email'])
			if self.compare_passwords(user, password)==True:
				return (True, user)
			else:
				errors.append('Password does not match email')
				return(False, errors)
		except:
			errors.append("Whoops! Looks like that email doesn't exist in the database")
			return (False, errors)

class User(models.Model):
	name = models.CharField(max_length=125)
	alias = models.CharField(max_length=125)
	email = models.CharField(max_length=255)
	password = models.CharField(max_length=255)
	birthday = models.DateField()
	objects = UserManager()

	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

